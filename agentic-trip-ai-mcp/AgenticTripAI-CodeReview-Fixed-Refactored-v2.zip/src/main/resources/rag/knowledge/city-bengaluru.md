# Bengaluru Travel Knowledge

- Country: India
- Airport: Kempegowda International Airport
- IATA: BLR
- ICAO: VOBL
- Knowledge type: destination-city / airport-directory

## RAG usage

Use this document to recognize `Bengaluru` and its airport identifiers when planning a trip. The IATA/ICAO values come from the project's seeded airport directory.

## Live-data boundary

Do not use this document for current flight schedules, ticket prices, hotel availability, weather, visa requirements, airport closures, or travel advisories. Those should be retrieved from live/authoritative sources through the project's MCP or research capabilities.
