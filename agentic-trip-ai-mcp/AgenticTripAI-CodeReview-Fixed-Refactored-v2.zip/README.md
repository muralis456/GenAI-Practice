# AgenticTripAI — Agentic RAG + MCP

This package is based on the latest AgenticTripAI MCP client project with LLM-based MCP tool selection, plus the MCP server. It adds Agentic RAG using Spring AI + PostgreSQL/pgvector + local Ollama embeddings.

## Architecture

```text
User
  |
  v
Intent -> Planner -> Agentic RAG -> Router
                         |
          LLM decides whether knowledge retrieval is needed
                         |
             +-----------+-----------+
             |                       |
       no retrieval             retrieve
             |                       |
             |                pgvector search
             |                       |
             |                evidence evaluation
             |                       |
             |                 refine + retry
             |                       |
             +-----------+-----------+
                         v
                 Parallel MCP Agents
                 /       |       \\
             Flight    Hotel    Weather/Research
                         |
                    Supervisor
                         |
                      Budget
                         |
                     Itinerary
                         |
                     Validator
                         |
                       HITL
```

### What makes this Agentic RAG

1. The LLM decides if internal knowledge retrieval is needed.
2. The LLM generates a semantic retrieval query.
3. Retrieval uses hybrid search: pgvector semantic search + PostgreSQL full-text search, fused with reciprocal-rank fusion.
4. An LLM reranks the candidate passages for direct relevance.
5. A grounded context compressor keeps only facts supported by the retrieved passages and preserves source labels.
6. The LLM evaluates whether the evidence is sufficient.
7. If insufficient, the LLM rewrites the query and retrieves again (bounded to `travel.rag.max-iterations`).
6. The resulting context is passed into itinerary generation and final tips.
7. Real-time flight/hotel/weather data continues to come from MCP tools, not the RAG store.

## Prerequisites

- Java 26
- PostgreSQL with pgvector
- Ollama running on `http://localhost:11434`
- `llama3.2:3b` for chat/reasoning
- `nomic-embed-text` for embeddings

Pull the local models:

```bash
ollama pull llama3.2:3b
ollama pull nomic-embed-text
```

Enable pgvector in the database:

```bash
psql -U postgres -d travel_agent -f database/init-pgvector.sql
```

The application has `spring.ai.vectorstore.pgvector.initialize-schema=true`, so Spring AI creates the `vector_store` table after the required PostgreSQL extensions are available. Spring AI's PGVector integration supports metadata filtering, similarity thresholds and HNSW indexing. See the official docs: https://docs.spring.io/spring-ai/reference/api/vectordbs/pgvector.html

## Run order

### 1. Start MCP server

```bash
cd agentic-trip-ai-mcp-server
mvn spring-boot:run
```

MCP endpoint: `http://localhost:8090/mcp`

### 2. Start Ollama

```bash
ollama serve
```

### 3. Start travel planner

```bash
cd agentic-trip-ai-mcp
mvn spring-boot:run
```

Planner endpoint/UI remains on port `8081`.

## RAG knowledge base

Bundled demo documents are under:

```text
agentic-trip-ai-mcp/src/main/resources/rag/knowledge/
```

The application seeds these documents when the `vector_store` table is empty.

To rebuild the index after editing those files:

```bash
curl -X POST http://localhost:8081/api/rag/reindex
```

The endpoint truncates the demo vector table and re-embeds the bundled knowledge files, so use it only for this development/demo knowledge index.

## Useful configuration

```yaml
travel:
  rag:
    enabled: true
    top-k: 5
    similarity-threshold: 0.55
    max-iterations: 2
    seed-on-empty: true
    hybrid:
      enabled: true
    rerank:
      enabled: true
    compression:
      enabled: true
```

Embedding model:

```yaml
spring:
  ai:
    ollama:
      embedding:
        model: nomic-embed-text
```

The Spring AI Ollama starter provides the `EmbeddingModel`; Ollama can run embedding models locally. See: https://docs.spring.io/spring-ai/reference/api/embeddings/ollama-embeddings.html

## Example behavior

Input:

```text
Plan a 5 day trip to Tokyo. I want local experiences, practical packing guidance and a balanced itinerary.
```

Expected flow:

```text
Planner
  -> Agentic RAG: retrieve=true
  -> query="Tokyo local experiences packing balanced itinerary"
  -> hybrid vector + keyword retrieval
  -> reciprocal-rank fusion
  -> LLM reranking
  -> grounded context compression
  -> evidence evaluation
  -> sufficient=true
  -> Router
  -> MCP flight/hotel/weather/research as required
  -> Itinerary receives RAG context
```

For:

```text
Find me a flight from Bangalore to Mumbai tomorrow.
```

The RAG router should normally return `retrieve=false`; the flight agent uses MCP instead.

## Important design boundary

RAG is for durable knowledge. MCP is still the source of real-time/actionable data in this project. This avoids putting stale flight prices, hotel inventory or weather into the vector database.

## Next-level Agentic RAG

The RAG node now implements a bounded production-style retrieval pipeline:

```text
LLM retrieval decision
        ↓
Semantic query
        ↓
┌───────────────┬────────────────┐
│ pgvector      │ PostgreSQL FTS │
│ semantic      │ keyword        │
└───────┬───────┴───────┬────────┘
        ↓               ↓
      Reciprocal-Rank Fusion
              ↓
         LLM Reranker
              ↓
    Grounded Context Compressor
              ↓
        Evidence Evaluator
          ↙           ↘
      sufficient     insufficient
         ↓                ↓
       Router       query rewrite
                          ↓
                       retrieve
```

This keeps the architecture intentionally local: Ollama handles embeddings and LLM calls, while PostgreSQL/pgvector provides durable knowledge storage.

The `/api/rag/reindex` endpoint remains a development/demo index rebuild endpoint. For production, replace the truncate-and-reload operation with versioned ingestion, document IDs, metadata filters, incremental updates and access-control-aware retrieval.


## Destination-aware Agentic RAG + Intelligent MCP Routing

The current MCP client now uses capability-aware routing before execution:

```text
Intent/Planner
     |
     +-- needsKnowledge=true --> Agentic RAG
     |                            |
     |                            +-- destination metadata filter
     |                            +-- multi-query retrieval
     |                            +-- vector + PostgreSQL FTS
     |                            +-- RRF + LLM reranking
     |                            +-- grounded compression
     |                            +-- evidence retry
     |
     +-- needsKnowledge=false ---+--> MCP specialist routing
                                      |
                                      +--> LLM selects discovered MCP tool
                                      +--> allow-list governance
                                      +--> structured arguments in selection context
```

RAG is intentionally skipped for purely live requests such as current flight availability, hotel availability/prices, current weather, and airport resolution. The `airport_location` database remains the single source of truth for city/airport records; its records are indexed with `destinationKey` metadata. Curated destination and city documents also carry destination metadata, allowing retrieval to be narrowed to the requested destination while retaining generic travel knowledge.
